import { Router } from 'express';
import { authMiddleware } from '../middleware/auth.js';
import { loadPermisos, requirePerm } from '../permisos.js';
import { answer } from '../jvbot/service.js';

const router = Router();
router.use(authMiddleware, loadPermisos(), requirePerm('ver_inventario'));

router.post('/chat', async (req, res) => {
  try {
    const { message, history } = req.body || {};
    if (typeof message !== 'string' || message.length > 1000) return res.status(400).json({ error: 'Mensaje inválido' });
    res.json(await answer(message, Array.isArray(history) ? history : []));
  } catch (error) { res.status(500).json({ error: 'No se pudo consultar EquipMaster' }); }
});

export default router;
