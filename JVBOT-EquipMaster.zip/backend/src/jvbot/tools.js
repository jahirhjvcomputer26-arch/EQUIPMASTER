import { firebaseGet } from '../firebase.js';

const number = value => Number(String(value ?? '').replace(/[$,\s]/g, '')) || 0;
const isSold = item => String(item.estado || '').includes('VENDIDO') || item.flujoSalida || item.flujoVentaML;
const daysSince = value => {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : Math.max(0, Math.floor((Date.now() - date.getTime()) / 86400000));
};

async function inventory() {
  const data = await firebaseGet('inventario');
  return data ? Object.values(data) : [];
}

export const tools = {
  async searchProducts(query) {
    const q = String(query || '').trim().toLowerCase();
    const items = await inventory();
    return items.filter(item => !q || ['codigo', 'sku', 'serie', 'marca', 'modelo', 'procesador', 'ram', 'almacenamiento'].some(field => String(item[field] || '').toLowerCase().includes(q))).slice(0, 25);
  },
  async getInventorySummary() {
    const items = await inventory();
    const available = items.filter(item => !isSold(item));
    const lowStock = available.filter(item => item.stock !== undefined ? number(item.stock) <= 2 : item.estado?.includes('BAJO STOCK'));
    const value = available.reduce((total, item) => total + number(item.precioPublico || item.precio), 0);
    return { total: items.length, disponibles: available.length, lowStock: lowStock.length, value, lowStockItems: lowStock.slice(0, 15) };
  },
  async getProductsByStock(kind) {
    const items = (await inventory()).filter(item => !isSold(item));
    return items.filter(item => kind === 'out' ? number(item.stock) === 0 || item.estado?.includes('AGOTADO') : number(item.stock) > 0 && number(item.stock) <= 2 || item.estado?.includes('BAJO STOCK')).slice(0, 25);
  },
  async getOldestProducts(limit = 10) {
    const items = (await inventory()).filter(item => !isSold(item)).map(item => ({ ...item, diasAlmacenado: daysSince(item.fechaRegistro) })).filter(item => item.diasAlmacenado !== null).sort((a, b) => b.diasAlmacenado - a.diasAlmacenado);
    return items.slice(0, limit);
  },
  async getProductBySku(sku) {
    const result = await this.searchProducts(sku);
    return result.find(item => String(item.sku || '').toLowerCase() === String(sku).toLowerCase()) || result[0] || null;
  },
};

export function publicProduct(item) {
  if (!item) return null;
  return { codigo: item.codigo, sku: item.sku, marca: item.marca, modelo: item.modelo, procesador: item.procesador, ram: item.ram, almacenamiento: item.almacenamiento, estado: item.estado, precio: item.precioPublico || item.precio, stock: item.stock, fechaRegistro: item.fechaRegistro };
}
