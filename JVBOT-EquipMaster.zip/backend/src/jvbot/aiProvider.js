export class AIProvider {
  async generate() {
    throw new Error('AIProvider no implementado');
  }
}

export class OpenAICompatibleProvider extends AIProvider {
  constructor({ apiKey, baseUrl, model }) {
    super();
    this.apiKey = apiKey;
    this.baseUrl = (baseUrl || 'https://api.openai.com/v1').replace(/\/$/, '');
    this.model = model || 'gpt-4o-mini';
  }

  async generate(messages) {
    const response = await fetch(`${this.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${this.apiKey}` },
      body: JSON.stringify({ model: this.model, temperature: 0.1, messages }),
    });
    if (!response.ok) throw new Error(`Proveedor IA respondió ${response.status}`);
    const data = await response.json();
    return data.choices?.[0]?.message?.content?.trim() || '';
  }
}

export function createAIProvider(env = process.env) {
  if (!env.AI_API_KEY) return null;
  return new OpenAICompatibleProvider({ apiKey: env.AI_API_KEY, baseUrl: env.AI_BASE_URL, model: env.AI_MODEL });
}
