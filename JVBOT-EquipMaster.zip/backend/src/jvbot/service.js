import { createAIProvider } from './aiProvider.js';
import { publicProduct, tools } from './tools.js';

const money = value => `$${Number(value || 0).toLocaleString('es-MX', { maximumFractionDigits: 0 })}`;
const list = items => items.slice(0, 10).map((item, index) => `${index + 1}. ${item.marca || ''} ${item.modelo || ''} · ${item.sku || item.codigo || 'sin SKU'}${item.diasAlmacenado !== undefined ? ` · ${item.diasAlmacenado} días` : ''}`).join('\n');
const safeData = data => Array.isArray(data)
  ? data.map(publicProduct)
  : data?.lowStockItems
    ? { ...data, lowStockItems: data.lowStockItems.map(publicProduct) }
    : data;

export async function answer(message, history = []) {
  const text = String(message || '').trim();
  const normalized = text.toLowerCase();
  if (!text) return { answer: 'Escribe una consulta sobre tu inventario.', tool: null, data: null };

  let tool = 'searchProducts';
  let data;
  let answerText;
  const code = text.match(/\b[A-Z][A-Z0-9-]*\d[A-Z0-9-]*\b/i)?.[0];
  const asksCount = /cu[aá]nt[oa]s?|cantidad|n[uú]mero/.test(normalized);
  if (asksCount && /estado\s+(ok|bueno)|disponible/.test(normalized)) {
    tool = 'searchProducts';
    data = (await tools.searchProducts('')).filter(item => String(item.estado || '').toUpperCase().includes('OK') && !String(item.estado || '').toUpperCase().includes('VENDIDO'));
    answerText = `Hay ${data.length} productos en estado OK.`;
  } else if (asksCount && code) {
    tool = 'getProductBySku';
    data = (await tools.searchProducts(code)).filter(item => [item.codigo, item.sku, item.serie].some(value => String(value || '').toLowerCase() === code.toLowerCase()));
    const stockQuestion = /stock|stok|existencia|existencias/.test(normalized);
    const stock = data.length === 1 && data[0].stock !== undefined ? data[0].stock : null;
    answerText = data.length
      ? stockQuestion && stock !== null
        ? `Hay ${stock} unidad${Number(stock) === 1 ? '' : 'es'} de ${code} en stock.`
        : `${code} corresponde a ${data.length} producto${data.length === 1 ? '' : 's'} registrado${data.length === 1 ? '' : 's'} en EquipMaster.`
      : `No encontré productos con el código o SKU ${code}.`;
  } else if (asksCount && /laptop|equipo|producto/.test(normalized)) {
    tool = 'searchProducts';
    const query = normalized.includes('laptop') ? 'laptop' : '';
    data = await tools.searchProducts(query);
    answerText = `Hay ${data.length} producto${data.length === 1 ? '' : 's'} que coinciden con esa consulta.`;
  } else if (/analiza|resumen|valor.*inventario|cu[aá]nto.*inventario/.test(normalized)) {
    tool = 'getInventorySummary'; data = await tools.getInventorySummary();
    answerText = `Inventario actual:\n• ${data.total} productos registrados.\n• ${data.disponibles} disponibles.\n• ${data.lowStock} con stock bajo.\n• Valor estimado disponible: ${money(data.value)}.`;
  } else if (/agotad|sin stock/.test(normalized)) {
    tool = 'getProductsByStock'; data = await tools.getProductsByStock('out');
    answerText = data.length ? `Encontré ${data.length} productos agotados:\n${list(data)}` : 'No encontré productos agotados.';
  } else if (/poco stock|stock bajo|bajo stock/.test(normalized)) {
    tool = 'getProductsByStock'; data = await tools.getProductsByStock('low');
    answerText = data.length ? `Encontré ${data.length} productos con stock bajo:\n${list(data)}` : 'No encontré productos con stock bajo.';
  } else if (/antigü|antigu|estancad|m[aá]s tiempo|viejo/.test(normalized)) {
    tool = 'getOldestProducts'; data = await tools.getOldestProducts();
    answerText = data.length ? `Productos con mayor antigüedad:\n${list(data)}` : 'No hay fechas de registro válidas para calcular antigüedad.';
  } else if (/sku/.test(normalized)) {
    const sku = text.match(/sku\s+([\w-]+)/i)?.[1] || text.split(/\s+/).pop();
    tool = 'getProductBySku'; data = await tools.getProductBySku(sku);
    const p = publicProduct(data);
    answerText = p ? `Encontré ${p.marca || ''} ${p.modelo || ''} (${p.sku || p.codigo}).\nProcesador: ${p.procesador || 'no registrado'} · RAM: ${p.ram || 'no registrada'} · Almacenamiento: ${p.almacenamiento || 'no registrado'}\nEstado: ${p.estado || 'no registrado'} · Precio: ${p.precio || 'no registrado'} · Stock: ${p.stock ?? 'no registrado'}.` : `No encontré un producto con el SKU ${sku}.`;
  } else {
    data = await tools.searchProducts(text.replace(/busca|buscar|qué|que|tengo|productos|producto/gi, '').trim());
    answerText = data.length ? `Encontré ${data.length} coincidencias:\n${list(data)}` : 'No encontré productos que coincidan con esa búsqueda.';
  }

  const provider = createAIProvider();
  if (provider) {
    try {
      const polished = await provider.generate([
        { role: 'system', content: 'Eres JVBOT de EquipMaster. Responde en español, de forma profesional y breve. Usa exclusivamente los datos JSON proporcionados; si falta un dato, dilo. No inventes.' },
        ...history.slice(-6),
        { role: 'user', content: `${text}\nDatos verificados por ${tool}:\n${JSON.stringify(safeData(data))}` },
      ]);
      if (polished) answerText = polished;
    } catch (error) { console.warn('JVBOT provider fallback:', error.message); }
  }
  return { answer: answerText, tool, data: safeData(data) };
}
