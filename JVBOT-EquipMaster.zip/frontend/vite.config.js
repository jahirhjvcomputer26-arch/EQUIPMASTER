import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    host: true,
    port: 5173,
    proxy: {
      '/api': process.env.VITE_DEV_API_TARGET || 'http://localhost:3001',
      '/archivos': process.env.VITE_DEV_API_TARGET || 'http://localhost:3001',
    },
  },
});
